package com.voidpanel.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

const val BRAND = "@ʜɪᴅᴅᴇɴ ᴀʀᴛ 🎨"
const val DAY = 86_400_000L
const val GEN_MS = 3 * 60 * 1000L
const val MAX_FAILS = 2

// Solo se guarda el hash de la key owner, nunca la key en texto.
private const val SALT = "void\$panel|"
private const val OWNER_HASH = "31f4c653a57b3b0a0b1794a5372cd56a6bb5abd0375717dda674948e1cc3c6bb"

data class VKey(val k: String, val exp: Long, var uses: Int, val total: Int, val owner: Boolean)

private val rng = SecureRandom()
private const val CH = "abcdefghijklmnopqrstuvwxyz0123456789"

/** n caracteres aleatorios (a-z, 0-9). */
fun randomChars(n: Int): String = (1..n).map { CH[rng.nextInt(CH.length)] }.joinToString("")

/** Estructura fija de toda key: <prefijo>-xxxxxxxxxx-xxxxxxxxxx[-sufijo] (las x no se pueden cambiar). */
const val KEY_PREFIX = "Proxy"
private fun body() = "${randomChars(10)}-${randomChars(10)}"

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

fun isOwnerKey(raw: String) = sha256(SALT + raw.trim().lowercase()) == OWNER_HASH

fun leftText(ms: Long): String {
    if (ms <= 0) return "expirada"
    val d = ms / DAY
    val h = ms % DAY / 3_600_000
    val m = ms % 3_600_000 / 60_000
    return if (d > 0) "${d}d ${h}h" else if (h > 0) "${h}h ${m}m" else "${m}m"
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("void_store", Context.MODE_PRIVATE)

    var fails: Int
        get() = p.getInt("fails", 0)
        set(v) { p.edit().putInt("fails", v).apply() }
    var locked: Boolean
        get() = p.getBoolean("locked", false)
        set(v) { p.edit().putBoolean("locked", v).apply() }
    var genStart: Long
        get() = p.getLong("genStart", 0L)
        set(v) { p.edit().putLong("genStart", v).apply() }
    var lastPub: String
        get() = p.getString("lastPub", "") ?: ""
        set(v) { p.edit().putString("lastPub", v).apply() }

    /** "owner", "user" o null si no hay sesión válida. */
    fun role(): String? {
        val r = p.getString("role", null) ?: return null
        if (r == "owner") return r
        if (System.currentTimeMillis() < p.getLong("until", 0L)) return r
        endSession(); return null
    }
    fun until(): Long = p.getLong("until", 0L)
    fun startSession(role: String, until: Long) {
        p.edit().putString("role", role).putLong("until", until).apply()
    }
    fun endSession() { p.edit().remove("role").remove("until").apply() }

    fun keys(): MutableList<VKey> {
        val now = System.currentTimeMillis()
        val arr = JSONArray(p.getString("keys", "[]"))
        val all = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            VKey(o.getString("k"), o.getLong("exp"), o.getInt("uses"), o.getInt("total"), o.getBoolean("owner"))
        }
        val ok = all.filter { it.exp > now && (it.owner || it.uses > 0) }.toMutableList()
        if (ok.size != all.size) save(ok)
        return ok
    }

    fun save(list: List<VKey>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("k", it.k).put("exp", it.exp).put("uses", it.uses)
                .put("total", it.total).put("owner", it.owner))
        }
        p.edit().putString("keys", arr.toString()).apply()
    }

    private fun uniqueKey(ks: List<VKey>, make: () -> String): String? {
        repeat(50) {
            val k = make()
            if (ks.none { it.k.equals(k, true) }) return k
        }
        return null
    }

    /** Key pública: Proxy-xxxxxxxxxx-xxxxxxxxxx, 1 uso, 24 h. */
    fun createPublic(): VKey {
        val ks = keys()
        val e = VKey(uniqueKey(ks) { "$KEY_PREFIX-${body()}" }!!, System.currentTimeMillis() + DAY, 1, 1, false)
        ks.add(e); save(ks)
        lastPub = e.k; genStart = 0L
        return e
    }

    /** Key owner: solo cambia el texto (prefijo y sufijo opcional); las x son fijas. */
    fun createOwner(prefix: String, suffix: String, days: Int, uses: Int): VKey? {
        val ks = keys()
        val k = uniqueKey(ks) { "$prefix-${body()}" + if (suffix.isEmpty()) "" else "-$suffix" } ?: return null
        val e = VKey(k, System.currentTimeMillis() + days * DAY, uses, uses, true)
        ks.add(e); save(ks)
        return e
    }

    fun delete(k: String) { save(keys().filter { it.k != k }) }

    /** null = ok; si no, mensaje de error. */
    fun login(raw: String): String? {
        val ks = keys()
        val e = ks.find { it.k.equals(raw.trim(), true) } ?: return "Key inválida"
        if (e.uses <= 0) return "Key ya usada"
        e.uses--; save(ks)
        startSession("user", e.exp)
        return null
    }
}

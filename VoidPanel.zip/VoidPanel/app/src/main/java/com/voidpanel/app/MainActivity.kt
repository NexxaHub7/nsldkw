package com.voidpanel.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!hasNotif()) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val store = Store(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                HiddenApp(this@MainActivity, store, tick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    fun hasNotif(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun hasOverlay(): Boolean = Settings.canDrawOverlays(this)

    /** Pide notificaciones y sobreposición si faltan (esta última abre sus ajustes). */
    fun requestPerms() {
        if (!hasNotif()) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (!hasOverlay()) openOverlaySettings()
    }

    private fun openOverlaySettings() {
        Toast.makeText(this, "Activa «Mostrar sobre otras apps» para $BRAND", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    /** true si arrancó; false si faltaba el permiso (y te lleva a concederlo). */
    fun runPanel(): Boolean {
        if (!hasOverlay()) { openOverlaySettings(); return false }
        if (!hasNotif()) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        return true
    }

    fun stopPanel() { stopService(Intent(this, FloatingService::class.java)) }

    fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Key", text))
        Toast.makeText(this, "Key copiada", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun HiddenApp(act: MainActivity, store: Store, tick: Int) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(if (store.role() != null) "main" else "lock") }
    var locked by remember { mutableStateOf(store.locked) }
    var fails by remember { mutableIntStateOf(store.fails) }
    var keyText by remember { mutableStateOf("") }
    var showOwner by remember { mutableStateOf(false) }
    var ownerIn by remember { mutableStateOf("") }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    // Los intentos limitados (2) son solo para entrar al AP (owner); el login normal no tiene límite.
    fun failOwner() {
        store.fails = store.fails + 1
        fails = store.fails
        if (store.fails >= MAX_FAILS) {
            store.locked = true; locked = true
            toast("Acceso al AP bloqueado para siempre")
        } else toast("Key owner incorrecta. Te queda ${MAX_FAILS - store.fails} intento")
    }
    fun granted(owner: Boolean) {
        if (owner) { store.fails = 0; fails = 0 }
        keyText = ""
        screen = "main"
        if (!owner) act.requestPerms()
    }

    BackHandler(enabled = screen == "gen") { screen = "lock" }

    Box(Modifier.fillMaxSize()) {
        AppBackground()
        Crossfade(screen, label = "screen") { s ->
            when (s) {
                "gen" -> GenScreen(store, act, { screen = "lock" }, { k -> keyText = k; screen = "lock"; toast("Key lista, pulsa Login") })
                "main" -> MainScreen(store, act, tick, ::toast) { screen = "lock"; locked = store.locked; fails = store.fails }
                else -> LockScreen(
                    keyText, { keyText = it },
                    onLogin = {
                        if (keyText.isBlank()) toast("Escribe tu key")
                        else {
                            val err = store.login(keyText)
                            if (err == null) granted(false) else toast(err)
                        }
                    },
                    onGen = { screen = "gen" },
                    onOwner = {
                        if (locked) toast("Acceso al AP bloqueado para siempre")
                        else { ownerIn = ""; showOwner = true }
                    }
                )
            }
        }
    }

    if (showOwner) {
        Dialog(onDismissRequest = { showOwner = false }) {
            VCard {
                Text(
                    "👑 OWNER", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp,
                    modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Gold, androidx.compose.ui.geometry.Offset.Zero, 20f))
                )
                Spacer(Modifier.height(6.dp))
                Note("Introduce la key secreta")
                Spacer(Modifier.height(4.dp))
                Note("Intentos restantes: ${MAX_FAILS - fails}", Gold.copy(alpha = .8f))
                Spacer(Modifier.height(14.dp))
                VField(ownerIn, { ownerIn = it }, "••••••••••••", password = true)
                Spacer(Modifier.height(14.dp))
                Row {
                    VButton("Cancelar", Modifier.weight(1f), BK.SEC, small = true) { showOwner = false }
                    Spacer(Modifier.width(10.dp))
                    VButton("Entrar", Modifier.weight(1f), BK.PRI, small = true) {
                        showOwner = false
                        val v = ownerIn; ownerIn = ""
                        if (!locked) {
                            if (isOwnerKey(v)) { store.startSession("owner", 0L); granted(true) }
                            else failOwner()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LockScreen(
    keyText: String, onKey: (String) -> Unit,
    onLogin: () -> Unit, onGen: () -> Unit, onOwner: () -> Unit
) {
    var taps by remember { mutableIntStateOf(0) }
    var last by remember { mutableLongStateOf(0L) }
    Page {
        Text("👑", fontSize = 26.sp)
        AppLogo(150.dp) {
            val now = System.currentTimeMillis()
            if (now - last > 2000) taps = 0
            last = now
            taps++
            if (taps >= 5) { taps = 0; onOwner() }
        }
        Spacer(Modifier.height(14.dp))
        AppTitle()
        Spacer(Modifier.height(10.dp))
        Chip("KEY SYSTEM")
        Spacer(Modifier.height(20.dp))
        VCard {
            CardTitle("Acceso")
            VField(keyText, onKey, "$KEY_PREFIX-xxxxxxxxxx-xxxxxxxxxx")
            Spacer(Modifier.height(14.dp))
            VButton("Login", onClick = onLogin)
            Spacer(Modifier.height(12.dp))
            VButton("Generar Key", kind = BK.SEC, onClick = onGen)
        }
        Spacer(Modifier.height(20.dp))
        Note("$BRAND · V1.0", P4.copy(alpha = .35f), 10)
    }
}

@Composable
fun GenScreen(store: Store, act: MainActivity, onBack: () -> Unit, onUse: (String) -> Unit) {
    var done by remember { mutableStateOf<VKey?>(null) }
    var rem by remember { mutableLongStateOf(GEN_MS) }
    LaunchedEffect(Unit) {
        val ex = store.keys().find { it.k == store.lastPub && it.uses > 0 }
        if (ex != null) { done = ex; return@LaunchedEffect }
        if (store.genStart == 0L) store.genStart = System.currentTimeMillis()
        while (true) {
            rem = GEN_MS - (System.currentTimeMillis() - store.genStart)
            if (rem <= 0) { done = store.createPublic(); break }
            delay(250)
        }
    }
    Page {
        AppLogo(112.dp)
        Spacer(Modifier.height(14.dp))
        Chip("GENERAR KEY")
        Spacer(Modifier.height(20.dp))
        VCard {
            val d = done
            if (d == null) {
                CardTitle("Generando…")
                Box(Modifier.size(200.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                        val st = Stroke(width = 24f, cap = StrokeCap.Round)
                        drawArc(P1.copy(alpha = .18f), 0f, 360f, false, size = Size(size.width, size.height), style = st)
                        drawArc(
                            Brush.sweepGradient(listOf(P4, P1, P3, P4)), -90f,
                            360f * (1f - rem / GEN_MS.toFloat()).coerceIn(0f, 1f), false,
                            size = Size(size.width, size.height), style = st
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val s = ((rem + 999) / 1000).coerceAtLeast(0)
                        Text(
                            "%02d:%02d".format(s / 60, s % 60), color = Color.White, fontSize = 42.sp,
                            fontWeight = FontWeight.Bold, fontFamily = Mono,
                            style = TextStyle(shadow = Shadow(P1, androidx.compose.ui.geometry.Offset.Zero, 24f))
                        )
                        Text("ESPERA", color = P2, fontSize = 10.sp, letterSpacing = 3.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Note("Tu key se generará cuando el contador llegue a 00:00.\nPuedes volver atrás, el tiempo sigue corriendo.")
            } else {
                CardTitle("Tu key")
                KeyBox(d.k)
                Spacer(Modifier.height(10.dp))
                Note("⏳ Válida 24 horas · 🔑 1 solo uso")
                Spacer(Modifier.height(14.dp))
                Row {
                    VButton("Copiar", Modifier.weight(1f), BK.SEC, small = true) { act.copy(d.k) }
                    Spacer(Modifier.width(10.dp))
                    VButton("Usar key", Modifier.weight(1f), BK.PRI, small = true) { onUse(d.k) }
                }
            }
            Spacer(Modifier.height(12.dp))
            VButton("← Volver", kind = BK.SEC, small = true, onClick = onBack)
        }
    }
}

@Composable
fun PermRow(label: String, ok: Boolean) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(shape).background(Color(0x880F0407))
            .border(1.dp, P1.copy(alpha = .3f), shape).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(if (ok) "Concedido ✔" else "Falta", color = if (ok) Ok else Bad, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StepBtn(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(13.dp)
    Box(
        Modifier.size(46.dp, 56.dp).clip(shape).background(P1.copy(alpha = .16f)).border(1.5.dp, P1.copy(alpha = .5f), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun MainScreen(store: Store, act: MainActivity, tick: Int, toast: (String) -> Unit, onLogout: () -> Unit) {
    var role by remember { mutableStateOf(store.role() ?: "user") }
    var running by remember { mutableStateOf(FloatingService.running) }
    var notif by remember { mutableStateOf(act.hasNotif()) }
    var over by remember { mutableStateOf(act.hasOverlay()) }
    var leftMs by remember { mutableLongStateOf(0L) }

    LaunchedEffect(tick) {
        while (true) {
            running = FloatingService.running
            notif = act.hasNotif()
            over = act.hasOverlay()
            val r = store.role()
            if (r == null) { onLogout(); break }
            role = r
            leftMs = store.until() - System.currentTimeMillis()
            delay(1000)
        }
    }
    val owner = role == "owner"

    Page {
        AppLogo(112.dp)
        Spacer(Modifier.height(10.dp))
        AppTitle(0.75f)
        Spacer(Modifier.height(12.dp))
        Chip(if (owner) "👑 OWNER" else "USUARIO", if (owner) Gold else Color.White)
        Spacer(Modifier.height(6.dp))
        Note(if (owner) "Acceso total" else "Sesión expira en ${leftText(leftMs)}", size = 11)

        if (owner) {
            // El owner solo sirve para generar keys.
            Spacer(Modifier.height(18.dp))
            OwnerGenerator(store, act, toast)
        } else {
            Spacer(Modifier.height(18.dp))
            VCard {
                CardTitle("Control")
                Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ventana flotante", color = P4, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    val c = if (running) Ok else P4.copy(alpha = .6f)
                    Text(
                        if (running) "● ACTIVO" else "● DETENIDO", color = c, fontSize = 12.sp,
                        fontWeight = FontWeight.Black, letterSpacing = 2.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, c.copy(alpha = .6f), RoundedCornerShape(50))
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
                VButton("Run Panel", enabled = !running) {
                    if (act.runPanel()) { toast("Panel iniciado"); running = true }
                    else toast("Concede el permiso de sobreposición")
                }
                Spacer(Modifier.height(12.dp))
                VButton("Stop Panel", kind = BK.RED, enabled = running) {
                    act.stopPanel(); running = false; toast("Panel detenido")
                }
                Text(
                    BRAND, color = P4.copy(alpha = .55f), fontSize = 10.sp,
                    modifier = Modifier.padding(top = 14.dp).align(Alignment.Start)
                )
            }

            Spacer(Modifier.height(16.dp))
            VCard {
                CardTitle("Permisos")
                PermRow("🔔  Notificaciones", notif)
                PermRow("🪟  Sobreposición", over)
                if (!notif || !over) VButton("Dar permisos", kind = BK.SEC, small = true) { act.requestPerms() }
            }


        }

        Spacer(Modifier.height(18.dp))
        VButton("Cerrar sesión", kind = BK.SEC, small = true) { store.endSession(); onLogout() }
    }
}

@Composable
fun OwnerGenerator(store: Store, act: MainActivity, toast: (String) -> Unit) {
    var days by remember { mutableStateOf("1") }
    var uses by remember { mutableStateOf("1") }
    var prefix by remember { mutableStateOf(KEY_PREFIX) }
    var suffix by remember { mutableStateOf("") }
    var made by remember { mutableStateOf("") }
    val list = remember { mutableStateListOf<VKey>() }
    fun refresh() { list.clear(); list.addAll(store.keys().filter { it.owner }.reversed()) }
    LaunchedEffect(Unit) { refresh() }
    val preview = "${prefix.ifBlank { "…" }}-xxxxxxxxxx-xxxxxxxxxx" + if (suffix.isEmpty()) "" else "-$suffix"

    fun step(v: String, d: Int, max: Int) = ((v.toIntOrNull() ?: 1) + d).coerceIn(1, max).toString()

    VCard {
        CardTitle("Generador de keys")
        Note("Días de duración", size = 11)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StepBtn("−") { days = step(days, -1, 365) }
            Spacer(Modifier.width(8.dp))
            VField(days, { days = it.filter(Char::isDigit).take(3) }, "1", Modifier.weight(1f), number = true, center = true)
            Spacer(Modifier.width(8.dp))
            StepBtn("+") { days = step(days, 1, 365) }
        }
        Spacer(Modifier.height(12.dp))
        Note("Usos", size = 11)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StepBtn("−") { uses = step(uses, -1, 9999) }
            Spacer(Modifier.width(8.dp))
            VField(uses, { uses = it.filter(Char::isDigit).take(4) }, "1", Modifier.weight(1f), number = true, center = true)
            Spacer(Modifier.width(8.dp))
            StepBtn("+") { uses = step(uses, 1, 9999) }
        }
        Spacer(Modifier.height(12.dp))
        Note("Formato de la key", size = 11)
        Spacer(Modifier.height(6.dp))
        VField(prefix, { prefix = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) }, KEY_PREFIX)
        Spacer(Modifier.height(8.dp))
        // Bloque fijo: las x no se pueden editar
        val lockShape = RoundedCornerShape(15.dp)
        Row(
            Modifier.fillMaxWidth().height(54.dp).clip(lockShape).background(P1.copy(alpha = .1f))
                .border(1.dp, P1.copy(alpha = .3f), lockShape).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("-xxxxxxxxxx-xxxxxxxxxx", color = P4.copy(alpha = .65f), fontFamily = Mono, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("🔒", fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))
        VField(suffix, { suffix = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) }, "sufijo (opcional)")
        Spacer(Modifier.height(8.dp))
        Text("Ejemplo: $preview", color = P2, fontFamily = Mono, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        VButton("Generar Key") {
            val d = (days.toIntOrNull() ?: 1).coerceIn(1, 365)
            val u = (uses.toIntOrNull() ?: 1).coerceIn(1, 9999)
            days = d.toString(); uses = u.toString()
            val pf = prefix.trim()
            if (pf.isEmpty()) toast("Escribe el texto del formato")
            else {
                val k = store.createOwner(pf, suffix.trim(), d, u)
                if (k == null) toast("No se pudo generar, prueba otro texto")
                else { made = k.k; refresh(); toast("Key creada") }
            }
        }
        if (made.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            KeyBox(made)
            Spacer(Modifier.height(10.dp))
            VButton("Copiar key", kind = BK.SEC, small = true) { act.copy(made) }
        }

        Spacer(Modifier.height(22.dp))
        CardTitle("Keys creadas")
        if (list.isEmpty()) Note("Aún no has creado keys")
        for (k in list) {
            val shape = RoundedCornerShape(13.dp)
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(shape).background(Color(0x990F0407))
                    .border(1.dp, P1.copy(alpha = .3f), shape).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(k.k, color = Color.White, fontFamily = Mono, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    Text("${k.uses}/${k.total} usos · ${leftText(k.exp - System.currentTimeMillis())}", color = P4.copy(alpha = .7f), fontSize = 11.sp)
                }
                MiniBtn("⧉", P1) { act.copy(k.k) }
                Spacer(Modifier.width(6.dp))
                MiniBtn("✕", Bad) { store.delete(k.k); refresh() }
            }
        }
    }
}

@Composable
fun MiniBtn(text: String, c: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(36.dp).clip(shape).background(c.copy(alpha = .15f)).border(1.dp, c.copy(alpha = .5f), shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 15.sp) }
}

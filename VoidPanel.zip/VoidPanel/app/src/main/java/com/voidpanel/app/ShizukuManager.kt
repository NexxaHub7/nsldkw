package com.voidpanel.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import rikka.shizuku.Shizuku

object ShizukuManager {
    private const val REQUEST_CODE = 2001
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun requestPermission(context: Context) {
        if (!isRunning()) {
            Toast.makeText(
                context,
                "Inicia Shizuku primero y vuelve a intentarlo",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (hasPermission()) {
            Toast.makeText(context, "Shizuku ya está autorizado", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
            Toast.makeText(
                context,
                "No se pudo solicitar la autorización de Shizuku",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun openShizuku(context: Context) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
            if (intent != null) {
                context.startActivity(intent)
            } else {
                Toast.makeText(
                    context,
                    "Instala Shizuku y vuelve a abrir VoidPanel",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (_: Throwable) {
            Toast.makeText(context, "No se pudo abrir Shizuku", Toast.LENGTH_SHORT).show()
        }
    }
}

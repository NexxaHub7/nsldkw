package com.voidpanel.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.voidpanel.app.STOP"
        private const val CHANNEL = "void_panel"
        private const val NOTIF_ID = 77
    }

    private var wm: WindowManager? = null
    private var bar: View? = null
    private var menu: View? = null
    private var arrow: ImageView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (bar == null) {
            try { showBar() } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        }
        running = true
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Void Panel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = b.setSmallIcon(R.drawable.ic_stat_void)
            .setContentTitle("Void Panel activo")
            .setContentText("La ventana flotante está en ejecución")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Detener", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ utilidades

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun shape(fill: String, radiusDp: Int, stroke: String? = null, strokeDp: Int = 0) =
        GradientDrawable().apply {
            setColor(Color.parseColor(fill))
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(strokeDp), Color.parseColor(stroke))
        }

    private fun icon(res: Int, sizeDp: Int) = ImageView(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun label(text: String, sp: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextColor(Color.parseColor(color))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun prefs() = getSharedPreferences("void_store", Context.MODE_PRIVATE)

    // ------------------------------------------------------- ventana pequeña

    @SuppressLint("ClickableViewAccessibility")
    private fun showBar() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val bmp = BitmapFactory.decodeResource(
            resources, R.drawable.logo, BitmapFactory.Options().apply { inSampleSize = 4 }
        )
        val logo = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat() }
        }
        val title = label("VOID PANEL", 13f, "#FFFFFF").apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            letterSpacing = 0.08f
        }
        val status = label("● Activo", 11f, "#B57CFF")
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            addView(title); addView(status)
        }
        val arrowView = icon(R.drawable.ic_arrow, 30)
        arrow = arrowView

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(10), dp(8))
            background = shape("#E6120A24", 18, "#8B3DFF", 2)
            elevation = dp(8).toFloat()
            addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(texts)
            addView(arrowView, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(6) })
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24); y = dp(160)
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        wm?.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMenu()
                    true
                }
                else -> false
            }
        }

        wm?.addView(root, lp)
        bar = root
    }

    // ------------------------------------------------------------------ menú

    private fun toggleMenu() { if (menu == null) openMenu() else closeMenu() }

    private fun closeMenu() {
        menu?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        menu = null
        arrow?.animate()?.rotation(0f)?.setDuration(180)?.start()
    }

    private fun makeToggle(initial: Boolean, onChange: (Boolean) -> Unit): View {
        val track = FrameLayout(this)
        val thumb = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        }
        track.addView(thumb, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER_VERTICAL).apply { leftMargin = dp(3) })
        var on = initial
        fun render(animate: Boolean) {
            track.background = if (on) shape("#8B3DFF", 14, "#D9C2FF", 1) else shape("#33FFFFFF", 14, "#55B57CFF", 1)
            val x = if (on) dp(22).toFloat() else 0f
            if (animate) thumb.animate().translationX(x).setDuration(160).start() else thumb.translationX = x
        }
        render(false)
        track.setOnClickListener { on = !on; render(true); onChange(on) }
        return track
    }

    private fun openMenu() {
        val dm = resources.displayMetrics
        val cardW = minOf(dp(340), (dm.widthPixels * 0.92f).toInt())

        // ---- barra lateral con la tab "Aim"
        val tab = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(9), dp(8), dp(9))
            background = shape("#338B3DFF", 12, "#8B3DFF", 1)
            addView(icon(R.drawable.ic_aim, 22))
            addView(label("Aim", 13f, "#FFFFFF", true).apply { setPadding(dp(6), 0, 0, 0) })
        }
        val brand = label("VOID", 11f, "#B57CFF", true).apply {
            letterSpacing = 0.3f
            setPadding(dp(4), 0, 0, dp(12))
        }
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(16), dp(8), dp(8))
            val r = dp(22).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#66000000"))
                cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
            addView(brand); addView(tab)
        }

        // ---- contenido: AimLock
        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            setOnClickListener { closeMenu() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(label("Aim", 17f, "#FFFFFF", true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(close, LinearLayout.LayoutParams(dp(30), dp(30)))
        }
        val divider = View(this).apply { setBackgroundColor(Color.parseColor("#448B3DFF")) }

        val on0 = prefs().getBoolean("aimlock", false)
        val status = label(if (on0) "Activado" else "Desactivado", 11f, if (on0) "#7CFFB2" else "#9C8BB8")
        val toggle = makeToggle(on0) { on ->
            prefs().edit().putBoolean("aimlock", on).apply()
            status.text = if (on) "Activado" else "Desactivado"
            status.setTextColor(Color.parseColor(if (on) "#7CFFB2" else "#9C8BB8"))
        }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(6), 0)
            addView(label("AimLock", 15f, "#FFFFFF", true)); addView(status)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape("#33000000", 14, "#668B3DFF", 1)
            addView(icon(R.drawable.ic_aimlock, 40))
            addView(names, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(toggle, LinearLayout.LayoutParams(dp(50), dp(28)))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            addView(header)
            addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(10); bottomMargin = dp(14)
            })
            addView(row)
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape("#F2120A24", 22, "#8B3DFF", 2)
            elevation = dp(16).toFloat()
            isClickable = true
            addView(side, LinearLayout.LayoutParams(dp(104), LinearLayout.LayoutParams.MATCH_PARENT))
            addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            alpha = 0f; scaleX = 0.88f; scaleY = 0.88f
        }

        val dim = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            setOnClickListener { closeMenu() }
            addView(card, FrameLayout.LayoutParams(cardW, dp(240), Gravity.CENTER))
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm?.addView(dim, lp)
        menu = dim
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        arrow?.animate()?.rotation(180f)?.setDuration(180)?.start()
    }

    override fun onDestroy() {
        menu?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bar?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        menu = null; bar = null
        running = false
        super.onDestroy()
    }
}

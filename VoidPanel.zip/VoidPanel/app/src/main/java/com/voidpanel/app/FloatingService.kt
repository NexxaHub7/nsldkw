package com.voidpanel.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.voidpanel.app.STOP"
        private const val CHANNEL = "void_panel"
        private const val NOTIF_ID = 77
    }

    private var wm: WindowManager? = null
    private var bar: View? = null
    private var menu: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (bar == null) {
            try { showBar() } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        }
        running = true
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, BRAND, NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = b.setSmallIcon(R.drawable.ic_stat_hidden)
            .setContentTitle("$BRAND activo")
            .setContentText("La ventana flotante está en ejecución")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Detener", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ utilidades

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun shape(fill: String, radiusDp: Int, stroke: String? = null, strokeDp: Int = 0) =
        GradientDrawable().apply {
            setColor(Color.parseColor(fill))
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(strokeDp), Color.parseColor(stroke))
        }

    private fun icon(res: Int, sizeDp: Int) = ImageView(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun label(text: String, sp: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextColor(Color.parseColor(color))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun prefs() = getSharedPreferences("void_store", Context.MODE_PRIVATE)

    // ------------------------------------------------------- ventana pequeña

    @SuppressLint("ClickableViewAccessibility")
    private fun showBar() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // Solo un círculo con el logo
        val root = roundedLogo(50, 25, 2, extraPad = 5).apply { elevation = dp(8).toFloat() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24); y = dp(160)
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        wm?.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMenu()
                    true
                }
                else -> false
            }
        }

        wm?.addView(root, lp)
        bar = root
    }

    /** Logo recortado con esquinas redondeadas y borde morado. */
    private fun roundedLogo(sizeDp: Int, radiusDp: Int, strokeDp: Int, extraPad: Int = 0): ImageView {
        val bmp = BitmapFactory.decodeResource(
            resources, R.drawable.logo, BitmapFactory.Options().apply { inSampleSize = 4 }
        )
        val pad = dp(strokeDp + extraPad)
        return ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setPadding(pad, pad, pad, pad)
            background = shape("#140609", radiusDp, "#FF5A6E", strokeDp)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }
    }

    // ------------------------------------------------------------------ menú

    private fun toggleMenu() { if (menu == null) openMenu() else closeMenu() }

    private fun closeMenu() {
        menu?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        menu = null
    }

    private fun makeToggle(initial: Boolean, onChange: (Boolean) -> Unit): View {
        val track = FrameLayout(this)
        val thumb = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        }
        track.addView(thumb, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER_VERTICAL).apply { leftMargin = dp(3) })
        var on = initial
        fun render(animate: Boolean) {
            track.background = if (on) shape("#D4152E", 14, "#FFC9CF", 1) else shape("#33FFFFFF", 14, "#55FF5A6E", 1)
            val x = if (on) dp(22).toFloat() else 0f
            if (animate) thumb.animate().translationX(x).setDuration(160).start() else thumb.translationX = x
        }
        render(false)
        track.setOnClickListener { on = !on; render(true); onChange(on) }
        return track
    }

    private fun gradient(vararg colors: String, o: GradientDrawable.Orientation, radiusDp: Int = 0) =
        GradientDrawable(o, colors.map { Color.parseColor(it) }.toIntArray()).apply {
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun sectionLabel(t: String) = label(t, 10f, "#B58E94", true).apply {
        letterSpacing = 0.2f
        setPadding(dp(2), 0, 0, dp(8))
    }

    /** Fila con icono, nombre, estado y toggle (solo guarda el estado, sin función aún). */
    private fun featureRow(iconRes: Int, name: String, key: String): View {
        val on0 = prefs().getBoolean(key, false)
        val status = label(if (on0) "Activado" else "Desactivado", 11f, if (on0) "#7CFFB2" else "#B58E94")
        val toggle = makeToggle(on0) { on ->
            prefs().edit().putBoolean(key, on).apply()
            status.text = if (on) "Activado" else "Desactivado"
            status.setTextColor(Color.parseColor(if (on) "#7CFFB2" else "#B58E94"))
        }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(6), 0)
            addView(label(name, 15f, "#FFFFFF", true)); addView(status)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = shape("#40000000", 14, "#77D4152E", 1)
            addView(icon(iconRes, 36))
            addView(names, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(toggle, LinearLayout.LayoutParams(dp(50), dp(28)))
        }
    }

    /** Cabeza / Cuello / Pecho: se elige uno. */
    private fun targetChips(): View {
        val opts = listOf("Cabeza", "Cuello", "Pecho")
        var sel = prefs().getString("aim_target", "") ?: ""
        val chips = mutableListOf<TextView>()
        fun paint() {
            chips.forEachIndexed { i, t ->
                val on = opts[i] == sel
                t.background = if (on) gradient("#FF4D5E", "#8E0F1F", o = GradientDrawable.Orientation.LEFT_RIGHT, radiusDp = 12)
                    .apply { setStroke(dp(1), Color.parseColor("#FFC9CF")) }
                else shape("#33000000", 12, "#55D4152E", 1)
                t.setTextColor(Color.parseColor(if (on) "#FFFFFF" else "#D9A8AE"))
            }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        opts.forEachIndexed { i, name ->
            val t = label(name, 13f, "#FFFFFF", true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener {
                    sel = if (sel == name) "" else name   // al activar una, la anterior se desactiva
                    prefs().edit().putString("aim_target", sel).apply()
                    paint()
                }
            }
            chips.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
        paint()
        return row
    }

    private fun aimPage() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(sectionLabel("FUNCIONES"))
        addView(featureRow(R.drawable.ic_assist, "Aim Assist", "aim_assist"))
        addView(sectionLabel("OBJETIVO").apply { setPadding(dp(2), dp(14), 0, dp(8)) })
        addView(targetChips())
    }

    private fun visualsPage() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(sectionLabel("FUNCIONES"))
        addView(featureRow(R.drawable.ic_esp, "Esp", "esp"))
        addView(
            featureRow(R.drawable.ic_box, "Box", "box"),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        )
    }

    private fun makeTab(iconRes: Int, name: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(6), dp(9), dp(6), dp(9))
        addView(
            View(this@FloatingService).apply {
                background = gradient("#FFE3E6", "#D4152E", o = GradientDrawable.Orientation.TOP_BOTTOM, radiusDp = 2)
            },
            LinearLayout.LayoutParams(dp(3), dp(20)).apply { marginEnd = dp(6) }
        )
        addView(icon(iconRes, 22))
        addView(label(name, 14f, "#FFFFFF", true).apply { setPadding(dp(7), 0, 0, 0) })
    }

    private fun openMenu() {
        val dm = resources.displayMetrics
        val cardW = minOf(dp(410), (dm.widthPixels * 0.96f).toInt())
        val cardH = minOf(dp(330), (dm.heightPixels * 0.9f).toInt())
        val fw = LinearLayout.LayoutParams.WRAP_CONTENT
        val mp = LinearLayout.LayoutParams.MATCH_PARENT

        // ---- tabs
        val tabs = listOf(makeTab(R.drawable.ic_aim, "Aim"), makeTab(R.drawable.ic_visuals, "Visuals"))
        val names = listOf("Aim", "Visuals")
        val titleTv = label("Aim", 19f, "#FFFFFF", true)
        val holder = FrameLayout(this)

        fun select(i: Int) {
            titleTv.text = names[i]
            holder.removeAllViews()
            holder.addView(if (i == 0) aimPage() else visualsPage())
            tabs.forEachIndexed { j, t ->
                t.background = if (j == i) shape("#33D4152E", 12, "#D4152E", 1) else shape("#00000000", 12, "#22D4152E", 1)
                t.getChildAt(0).visibility = if (j == i) View.VISIBLE else View.INVISIBLE
            }
        }
        tabs.forEachIndexed { i, t -> t.setOnClickListener { select(i) } }

        // ---- barra lateral
        val brand = label(BRAND, 9f, "#FFC9CF", true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
        }
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(16), dp(8), dp(10))
            val r = dp(22).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#66000000"))
                cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
            addView(roundedLogo(64, 16, 2))
            addView(brand, LinearLayout.LayoutParams(mp, fw).apply { topMargin = dp(7); bottomMargin = dp(16) })
            addView(tabs[0], LinearLayout.LayoutParams(mp, fw))
            addView(tabs[1], LinearLayout.LayoutParams(mp, fw).apply { topMargin = dp(6) })
            addView(View(this@FloatingService), LinearLayout.LayoutParams(1, 0, 1f))
            addView(label("v1.0", 9f, "#8F5A63"))
        }

        // ---- contenido
        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            setOnClickListener { closeMenu() }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleTv)
            addView(label("by $BRAND", 10f, "#FF5A6E"))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titles, LinearLayout.LayoutParams(0, fw, 1f))
            addView(close, LinearLayout.LayoutParams(dp(30), dp(30)))
        }
        val divider = View(this).apply {
            background = gradient("#D4152E", "#FF5A6E", "#00D4152E", o = GradientDrawable.Orientation.LEFT_RIGHT, radiusDp = 1)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            addView(header)
            addView(divider, LinearLayout.LayoutParams(mp, dp(2)).apply { topMargin = dp(10); bottomMargin = dp(12) })
            addView(holder)
            addView(View(this@FloatingService), LinearLayout.LayoutParams(1, 0, 1f))
            addView(label("$BRAND · v1.0", 9f, "#8F5A63"))
        }

        // ---- marca de agua + decoraciones
        val watermark = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.10f
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(side, LinearLayout.LayoutParams(dp(118), mp))
            addView(content, LinearLayout.LayoutParams(0, mp, 1f))
        }
        val inner = FrameLayout(this).apply {
            background = shape("#F7140609", 22)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(watermark, FrameLayout.LayoutParams(mp, mp))
            addView(body, FrameLayout.LayoutParams(mp, mp))
            addView(label("✦", 16f, "#FF5A6E").apply { alpha = 0.8f },
                FrameLayout.LayoutParams(fw, fw, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(14); bottomMargin = dp(10) })
            addView(label("✧", 11f, "#FFC9CF").apply { alpha = 0.6f },
                FrameLayout.LayoutParams(fw, fw, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(34); bottomMargin = dp(22) })
            addView(label("✦", 9f, "#FF5A6E").apply { alpha = 0.5f },
                FrameLayout.LayoutParams(fw, fw, Gravity.TOP or Gravity.START).apply { leftMargin = dp(128); topMargin = dp(8) })
        }
        val card = FrameLayout(this).apply {
            background = gradient("#FFE3E6", "#D4152E", "#8E0F1F", "#FF5A6E", o = GradientDrawable.Orientation.TL_BR, radiusDp = 24)
            setPadding(dp(2), dp(2), dp(2), dp(2))
            elevation = dp(16).toFloat()
            isClickable = true
            addView(inner, FrameLayout.LayoutParams(mp, mp))
            alpha = 0f; scaleX = 0.88f; scaleY = 0.88f
        }

        val dim = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            setOnClickListener { closeMenu() }
            addView(card, FrameLayout.LayoutParams(cardW, cardH, Gravity.CENTER))
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        select(0)
        wm?.addView(dim, lp)
        menu = dim
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    override fun onDestroy() {
        menu?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bar?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        menu = null; bar = null
        running = false
        super.onDestroy()
    }
}

package com.voidpanel.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

val Bg = Color(0xFF0A0612)
val P1 = Color(0xFF8B3DFF)
val P2 = Color(0xFFB57CFF)
val P3 = Color(0xFF5B21FF)
val P4 = Color(0xFFD9C2FF)
val Ok = Color(0xFF7CFFB2)
val Bad = Color(0xFFFF4D6D)
val Gold = Color(0xFFFFD166)
val CardBg = Color(0xCC140B28)
val Mono = FontFamily.Monospace

/** Fondo: degradados morados que se mueven + brasas flotando. */
@Composable
fun VoidBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "p")
    val seeds = remember {
        List(38) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2.4f + .8f, (1 + Random.nextInt(3)).toFloat()) }
    }
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Bg)
        val a = sin(p * 2 * PI).toFloat()
        val w = size.width
        val h = size.height
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF3B0F8F).copy(alpha = .8f), Color.Transparent), Offset(w * (.5f + .18f * a), h * .06f), w * 1.2f),
            w * 1.2f, Offset(w * (.5f + .18f * a), h * .06f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF4A12B8).copy(alpha = .55f), Color.Transparent), Offset(w * (.9f - .2f * a), h), w * 1.0f),
            w * 1.0f, Offset(w * (.9f - .2f * a), h)
        )
        drawLine(P1.copy(alpha = .13f), Offset(-40f, h * (.28f + .03f * a)), Offset(w + 40f, h * (.12f - .03f * a)), strokeWidth = 110f)
        drawLine(P3.copy(alpha = .12f), Offset(-40f, h * (.92f - .03f * a)), Offset(w + 40f, h * (.76f + .03f * a)), strokeWidth = 90f)
        val d = density
        for (s in seeds) {
            val k = s[3]
            val y = h * (1f - ((p * k + s[0]) % 1f))
            val x = w * s[1] + sin((p * k * 2 * PI + s[0] * 6.28).toFloat()) * 14f * d
            val r = s[2] * d
            drawCircle(P2.copy(alpha = .22f), r * 3.4f, Offset(x, y))
            drawCircle(P4.copy(alpha = .85f), r, Offset(x, y))
        }
    }
}

@Composable
fun VoidLogo(size: Dp, onClick: (() -> Unit)? = null) {
    val t = rememberInfiniteTransition(label = "logo")
    val g by t.animateFloat(12f, 34f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    val shape = RoundedCornerShape(size * 0.22f)
    var m: Modifier = Modifier.size(size).shadow(g.dp, shape, ambientColor = P1, spotColor = P2)
        .clip(shape).border(3.dp, Brush.linearGradient(listOf(P4, P1, P3, P2)), shape)
    if (onClick != null) {
        m = m.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    }
    Image(painterResource(R.drawable.logo), "Void Panel", m, contentScale = ContentScale.Crop)
}

@Composable
fun VoidTitle(scale: Float = 1f) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "VOID", color = Color.White, fontSize = (50 * scale).sp, lineHeight = (48 * scale).sp,
            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 3.sp,
            style = TextStyle(shadow = Shadow(P2, Offset(3f, 3f), 24f))
        )
        Text(
            "PANEL", color = P2, fontSize = (40 * scale).sp, lineHeight = (40 * scale).sp,
            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 5.sp,
            style = TextStyle(shadow = Shadow(P1, Offset(2f, 2f), 26f))
        )
    }
}

@Composable
fun Chip(text: String, color: Color = P4) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(P1.copy(alpha = .13f))
            .border(1.dp, P1.copy(alpha = .5f), RoundedCornerShape(50)).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
    }
}

@Composable
fun VCard(modifier: Modifier = Modifier, danger: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val line = if (danger) Brush.linearGradient(listOf(Bad, Bad.copy(alpha = .3f), Bad))
    else Brush.linearGradient(listOf(P2, P1.copy(alpha = .25f), P3))
    Column(
        modifier.fillMaxWidth().clip(shape).background(CardBg).border(1.2.dp, line, shape).padding(20.dp),
        content = content
    )
}

@Composable
fun CardTitle(text: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text.uppercase(), color = P2, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(P1.copy(alpha = .5f), Color.Transparent))))
    }
}

enum class BK { PRI, SEC, RED }

@Composable
fun VButton(
    text: String, modifier: Modifier = Modifier, kind: BK = BK.PRI, enabled: Boolean = true,
    small: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(if (small) 12.dp else 15.dp)
    val bg = when (kind) {
        BK.PRI -> Brush.horizontalGradient(listOf(Color(0xFFA55BFF), Color(0xFF6A2BFF), Color(0xFF4B19E0)))
        BK.RED -> Brush.horizontalGradient(listOf(Color(0xFFFF4D6D), Color(0xFFC01A45)))
        BK.SEC -> Brush.horizontalGradient(listOf(P1.copy(alpha = .12f), P1.copy(alpha = .12f)))
    }
    var m = modifier.fillMaxWidth().height(if (small) 42.dp else 54.dp).alpha(if (enabled) 1f else .35f)
        .clip(shape).background(bg)
    if (kind == BK.SEC) m = m.border(1.5.dp, P1, shape)
    Box(m.clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(
            text.uppercase(), color = if (kind == BK.SEC) P4 else Color.White,
            fontWeight = FontWeight.Black, fontSize = if (small) 12.sp else 15.sp, letterSpacing = 2.sp
        )
    }
}

@Composable
fun VField(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    password: Boolean = false, number: Boolean = false, center: Boolean = false
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = modifier.fillMaxWidth(), singleLine = true,
        placeholder = { Text(hint, color = P4.copy(alpha = .35f), fontFamily = Mono) },
        textStyle = TextStyle(
            color = Color.White, fontFamily = Mono, fontSize = 15.sp,
            textAlign = if (center) androidx.compose.ui.text.style.TextAlign.Center else androidx.compose.ui.text.style.TextAlign.Start
        ),
        shape = RoundedCornerShape(15.dp),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None, autoCorrect = false,
            keyboardType = if (number) KeyboardType.Number else if (password) KeyboardType.Password else KeyboardType.Ascii
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = P2, unfocusedBorderColor = P1.copy(alpha = .45f), cursorColor = P2,
            focusedContainerColor = Color(0xCC08040F), unfocusedContainerColor = Color(0xCC08040F)
        )
    )
}

@Composable
fun KeyBox(text: String) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xDD08040F)).border(1.5.dp, P2, shape).padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = Color.White, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            lineHeight = 22.sp, style = TextStyle(shadow = Shadow(P1, Offset.Zero, 18f)),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun Note(text: String, color: Color = P4.copy(alpha = .7f), size: Int = 12) {
    Text(
        text, color = color, fontSize = size.sp, lineHeight = (size + 6).sp,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth()
    )
}

/** Página centrada y con scroll. */
@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = maxHeight
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).heightIn(min = h)
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            content = content
        )
    }
}
